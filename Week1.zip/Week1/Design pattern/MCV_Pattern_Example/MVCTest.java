package MVCPatternExample;
/*
 * Name :- Gopinath Panigrahi
 * mail :- gopinathpanigrahi2004@gmail.com
 * Superset ID: 6381863
 */
public class MVCTest {
    public static void main(String[] args) {
        Student model = new Student("Parinita", "S12112343", "A");
        StudentView view = new StudentView();
        StudentController controller = new StudentController(model, view);

        controller.updateView();
        controller.setStudentName("Bishal");
        controller.setStudentGrade("B+");
        controller.updateView();
    }
}