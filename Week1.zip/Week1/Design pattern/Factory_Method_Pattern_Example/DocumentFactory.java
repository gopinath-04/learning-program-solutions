package FactoryMethodPatternExample;
/*
 * Name :- Gopinath Panigrahi
 * mail :- gopinathpanigrahi2004@gmail.com
 * Superset ID: 6381863
 */
public abstract class DocumentFactory {
    public abstract Document createDocument();
}