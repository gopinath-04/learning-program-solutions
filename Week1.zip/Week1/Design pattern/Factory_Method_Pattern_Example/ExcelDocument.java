package FactoryMethodPatternExample;
/*
 * Name :- Gopinath Panigrahi
 * mail :- gopinathpanigrahi2004@gmail.com
 * Superset ID: 6381863
 */
public class ExcelDocument implements Document {
    public void open() {
        System.out.println("Opening Excel document.");
    }
}