package FactoryMethodPatternExample;
/*
 * Name :- Gopinath Panigrahi
 * mail :- gopinathpanigrahi2004@gmail.com
 * Superset ID: 6381863
 */
public class WordDocument implements Document {
    public void open() {
        System.out.println("Opening Word document.");
    }
}