package StrategyPatternExample;
/*
 * Name :- Gopinath Panigrahi
 * mail :- gopinathpanigrahi2004@gmail.com
 * Superset ID: 6381863
 */
public class PayPalPayment implements PaymentStrategy {
    public void pay(double amount) {
        System.out.println("Paid " + amount + " using PayPal.");
    }
}