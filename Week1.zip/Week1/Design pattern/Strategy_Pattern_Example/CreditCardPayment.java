package StrategyPatternExample;
/*
 * Name :- Gopinath Panigrahi
 * mail :- gopinathpannigrahi2004@gmail.com
 * Superset ID: 6381863
 */
public class CreditCardPayment implements PaymentStrategy {
    public void pay(double amount) {
        System.out.println("Paid " + amount + " using Credit Card.");
    }
}