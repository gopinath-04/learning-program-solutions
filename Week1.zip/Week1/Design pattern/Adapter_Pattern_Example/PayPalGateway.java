package AdapterPatternExample;
/*
 * Name :- Gopinath Panigrahi
 * mail :- gopinathpanigrahi2004@gmail.com
 * Superset ID: 6381863
 */
public class PayPalGateway {
    public void sendPayment(double amount) {
        System.out.println("Paid " + amount + " using PayPal.");
    }
}