package AdapterPatternExample;
/*
 * Name :- Gopinath Panigrahi
 * mail :- gopinathpanigrahi2004@gmail.com
 * Superset ID: 6381863
 */
public class PayPalAdapter implements PaymentProcessor {
    private PayPalGateway gateway = new PayPalGateway();

    public void processPayment(double amount) {
        gateway.sendPayment(amount);
    }
}