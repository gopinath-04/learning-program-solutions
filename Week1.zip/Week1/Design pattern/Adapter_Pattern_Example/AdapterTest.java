package AdapterPatternExample;
/*
 * Name :- Gopinath Panigrahi
 * mail :- gopinathpannigrahi2004@gmail.com
 * Superset ID: 6381863
 */
public class AdapterTest {
    public static void main(String[] args) {
        PaymentProcessor processor = new PayPalAdapter();
        processor.processPayment(150.00);
    }
}