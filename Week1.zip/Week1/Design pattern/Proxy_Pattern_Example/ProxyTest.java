package ProxyPatternExample;
/*
 * Name :- Gopinath Panigrahi
 * mail :- gopinathpanigrahi2004@gmail.com
 * Superset ID: 6381863
 */
public class ProxyTest {
    public static void main(String[] args) {
        Image image = new ProxyImage("photo1.jpg");
        image.display();
        image.display(); 
    }
}