package ObserverPatternExample;
/*
 * Name :- Gopinath Panigrahi
 * mail :- gopinathpanigrahi2004@gmail.com
 * Superset ID: 6381863
 */
public class MobileApp implements Observer {
    public void update(float price) {
        System.out.println("Mobile App - Stock price updated to: " + price);
    }
}