package ObserverPatternExample;
/*
 * Name :- Gopinath Panigrahi2004
 * mail :- gopinathpanigrahi2004@gmail.com
 * Superset ID: 6381863
 */
public class WebApp implements Observer {
    public void update(float price) {
        System.out.println("Web App - Stock price updated to: " + price);
    }
}