public interface ExternalApi {
    String getData();
    void sendData(String data);
    void riskyOperation();
}
