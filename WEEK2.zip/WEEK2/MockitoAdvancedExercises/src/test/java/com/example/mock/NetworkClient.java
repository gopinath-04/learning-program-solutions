package com.example.mock;

public interface NetworkClient {
    String connect();
}