package com.example.mock;

public interface FileWriter {
    void write(String data);
}