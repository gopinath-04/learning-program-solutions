package com.example.mock;

public interface RestClient {
    String getResponse();
}