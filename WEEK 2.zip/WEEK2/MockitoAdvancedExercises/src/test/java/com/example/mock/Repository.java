package com.example.mock;

public interface Repository {
    String getData();
}