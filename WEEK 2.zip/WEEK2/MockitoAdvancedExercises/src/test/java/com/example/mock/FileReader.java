package com.example.mock;

public interface FileReader {
    String read();
}