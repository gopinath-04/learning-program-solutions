import React from 'react';

function User() {
  return (
    <div>
      <h2>Welcome User!</h2>
      <p>You can now book your flight tickets. ✅</p>
      <button>Book Tickets</button>
    </div>
  );
}

export default User;
