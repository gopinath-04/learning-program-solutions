import React from 'react';

function CourseDetails() {
  return (
    <div>
      <h2>🎓 Course Details</h2>
      <p>Course: React Masterclass</p>
      <p>Instructor: Sujeet Panda</p>
    </div>
  );
}

export default CourseDetails;
