import React from 'react';
import './App.css';
import OnlineShopping from './OnlineShopping'; // Make sure the path is correct

function App() {
  return (
    <div className="App">
      <OnlineShopping />
    </div>
  );
}

export default App;